import logging

from aiogram import Bot, Dispatcher, types, executor
from main import checkWord
from config import token

logging.basicConfig(level=logging.INFO)

bot = Bot(token=token)
dp = Dispatcher(bot)


@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    await message.reply('Imlo Botga Xush Kelipsiz!\n \nSo`z kiriting!')


@dp.message_handler(commands=['help'])
async def help_user(message: types.Message):
    await message.reply('Botdan foydalanish uchun so`z yuboring!')


@dp.message_handler()
async def checkImlo(message: types.Message):
    # Split the message text into words
    words = message.text.split()
    responses = []

    for word in words:
        result = checkWord(word)
        if result['available']:
            response = f"✅{word.capitalize()}"
        else:
            response = f"❌{word.capitalize()}"
            for text in result['matches']:
                response += f"\n✅{text.capitalize()}"
        responses.append(response)

    # Send responses for each word
    for response in responses:
        await message.answer(response)


if __name__ == '__main__':

    executor.start_polling(dp, skip_updates=False)
